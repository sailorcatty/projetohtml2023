var n1 = parseInt(prompt('Informe o primeiro valor: '));
var n2 = parseInt(prompt('Informe o segundo valor: '));

// parseFloat() para converter para números reais.

//alert (n1+n2);

result.innerHTML = n1+n2

var resp = confirm("Podemos continuar?");

document.write("<p>" + resp + "</p>");

//console.log(n1+n2);