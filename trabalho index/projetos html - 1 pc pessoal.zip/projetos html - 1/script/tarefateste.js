var n1 = parseInt(prompt('Informe o primeiro valor: '));
    var n2 = parseInt(prompt('Informe o segundo valor: '));

    if (n1 > n2){
        print("o primeiro é maior que o segundo");
    }