var raio = parseInt(prompt('Informe a(s) hora(s): '));

var tmin = (hor * 60) + min;

document.write(é equivalente à);
